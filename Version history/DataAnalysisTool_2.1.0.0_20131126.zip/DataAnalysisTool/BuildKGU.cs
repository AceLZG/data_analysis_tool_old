﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Vanchip.Data;
using Vanchip.Common;

namespace DataAnalysisTool
{
    public partial class BuildKGU : Form
    {
        private string strGoldenPath = @".\GoldenSample\";
        DataParse _DataParse = new DataParse();

        public BuildKGU()
        {
            InitializeComponent();
            lbxProduct.SelectedIndexChanged += new EventHandler(lbxProduct_SelectedIndexChanged);
        }

        void lbxProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fileName = strGoldenPath + lbxProduct.SelectedItem.ToString();
            string lineConent = "";
            tbxHeader.Text = "";

            #region *** Read to memory ***
            //string content = string.Empty;
            //using (StreamReader ms_StreamReader = new StreamReader(fileName))
            //{
            //    content = ms_StreamReader.ReadToEnd();//一次性读入内存
            //}
            //MemoryStream _MemoryStream = new MemoryStream(Encoding.GetEncoding("GB2312").GetBytes(content));//放入内存流，以便逐行读取
            //StreamReader _StreamReader = new StreamReader(_MemoryStream);
            #endregion *** Read to memory ***

            #region *** Direct Read ***
            FileStream _FileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            StreamReader _StreamReader = new StreamReader(_FileStream);
            _StreamReader.BaseStream.Seek(0, SeekOrigin.Begin);

            #endregion *** Diresct Read ***

            lineConent = _StreamReader.ReadLine();
            StringBuilder sbHeader = new StringBuilder();
            while (lineConent != null && !lineConent.Contains("Data"))
            {
                if (lineConent.Contains("Header")) lineConent = _StreamReader.ReadLine();

                lineConent = lineConent.Replace(",", " ");
                sbHeader.AppendLine(lineConent.Trim());

                lineConent = _StreamReader.ReadLine();
            }
            tbxHeader.Text = sbHeader.ToString();
        }

        private void BuildKGU_Load(object sender, EventArgs e)
        {
            DirectoryInfo DI = new DirectoryInfo(strGoldenPath);
            FileInfo[] FI = DI.GetFiles();

            foreach (FileInfo fi in FI)
            {
                lbxProduct.Items.Add(fi.Name);
            }
        }

        private void btnBuild_Click(object sender, EventArgs e)
        {
            string fileName = strGoldenPath + lbxProduct.SelectedItem.ToString();

            //Header info
            StringBuilder sbHeader = new StringBuilder();
            sbHeader.AppendLine("Header Section");
            sbHeader.Append(tbxHeader.Text);
            sbHeader.AppendLine("Data Section");

            DataTable tblKGUData = new DataTable();
            DataHeader tHeader = new DataHeader();
            tHeader = _DataParse.Header;

            #region *** Parsing data ***
            try
            {
                tblKGUData = _DataParse.GetDataFromCsv(fileName);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            #endregion *** Parsing data ***

            #region *** Save file ***
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            if (tblKGUData.Rows.Count == 0)
            {
                MessageBox.Show("No Test data need to be saved", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            saveFileDialog1.Title = "Save KGU file as";
            saveFileDialog1.FileName = lbxProduct.SelectedItem.ToString() + "_LTX";
            saveFileDialog1.Filter = "ASCII File|*.*";
            if (saveFileDialog1.ShowDialog() != DialogResult.OK) return;

            StreamWriter swData = new StreamWriter(saveFileDialog1.FileName);
            StringBuilder sbContent = new StringBuilder();
            //Header
            swData.Write(sbHeader);

            foreach (DataRow drTemp in tblKGUData.Rows)
            {
                sbContent = new StringBuilder();
                int RowIndex = tblKGUData.Rows.IndexOf(drTemp);

                if (RowIndex == 0)
                {
                    sbContent.Append("Test_Num ");
                    for (int i = 3; i < tblKGUData.Columns.Count - 3; i++)
                    {
                        sbContent.Append(i - 2);
                        sbContent.Append(" ");
                    }
                    swData.WriteLine(sbContent.ToString());

                    sbContent = new StringBuilder();
                    drTemp[2] = "Test_Item";
                }
                else if (RowIndex == 1)
                {
                    drTemp[2] = "L_Tol";
                }
                else if (RowIndex == 2)
                {
                    drTemp[2] = "H_Tol";
                }
                else if (RowIndex == 3)
                {
                    drTemp[2] = "Enable";
                }

                for (int i = 2; i < tblKGUData.Columns.Count - 3; i++)
                {
                    string strTemp;
                    if (RowIndex == 0)
                    {
                        strTemp = drTemp[i].ToString().Replace(" ", "_");
                    }
                    else if (RowIndex == 1 || RowIndex == 2)
                    {
                        if (drTemp[i].ToString() == "")
                            strTemp = "0";
                        else
                            strTemp = drTemp[i].ToString();
                    }
                    else
                    {
                        strTemp = drTemp[i].ToString();
                    }

                    sbContent.Append(strTemp);
                    sbContent.Append(" ");
                }
                if (RowIndex == tblKGUData.Rows.Count - 1)
                    swData.Write(sbContent.ToString());
                else
                    swData.WriteLine(sbContent.ToString());
            }
            swData.Close();

            MessageBox.Show("KGU file build successfully, new KGU file has been saved to " + saveFileDialog1.FileName, "Build KGU", MessageBoxButtons.OK);

            #endregion *** Save file ***

        }
    }
}
