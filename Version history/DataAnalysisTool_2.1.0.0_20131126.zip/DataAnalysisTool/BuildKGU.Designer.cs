﻿namespace DataAnalysisTool
{
    partial class BuildKGU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxProduct = new System.Windows.Forms.ListBox();
            this.lblinfo = new System.Windows.Forms.Label();
            this.tbxHeader = new System.Windows.Forms.TextBox();
            this.btnBuild = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxProduct
            // 
            this.lbxProduct.BackColor = System.Drawing.SystemColors.Window;
            this.lbxProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbxProduct.FormattingEnabled = true;
            this.lbxProduct.Location = new System.Drawing.Point(12, 12);
            this.lbxProduct.Name = "lbxProduct";
            this.lbxProduct.Size = new System.Drawing.Size(211, 468);
            this.lbxProduct.TabIndex = 0;
            // 
            // lblinfo
            // 
            this.lblinfo.Location = new System.Drawing.Point(13, 491);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(563, 26);
            this.lblinfo.TabIndex = 1;
            // 
            // tbxHeader
            // 
            this.tbxHeader.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbxHeader.Location = new System.Drawing.Point(229, 270);
            this.tbxHeader.Multiline = true;
            this.tbxHeader.Name = "tbxHeader";
            this.tbxHeader.Size = new System.Drawing.Size(347, 210);
            this.tbxHeader.TabIndex = 2;
            // 
            // btnBuild
            // 
            this.btnBuild.Location = new System.Drawing.Point(327, 88);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.Size = new System.Drawing.Size(160, 77);
            this.btnBuild.TabIndex = 3;
            this.btnBuild.Text = "Build";
            this.btnBuild.UseVisualStyleBackColor = true;
            this.btnBuild.Click += new System.EventHandler(this.btnBuild_Click);
            // 
            // BuildKGU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 526);
            this.Controls.Add(this.btnBuild);
            this.Controls.Add(this.tbxHeader);
            this.Controls.Add(this.lblinfo);
            this.Controls.Add(this.lbxProduct);
            this.Name = "BuildKGU";
            this.Text = "BuildKGU";
            this.Load += new System.EventHandler(this.BuildKGU_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbxProduct;
        private System.Windows.Forms.Label lblinfo;
        private System.Windows.Forms.TextBox tbxHeader;
        private System.Windows.Forms.Button btnBuild;
    }
}