﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DataAnalysisTool
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            label1.Text = "Data Analysis Tool 1.3.0.0\r\n   \r\n2012-07-04";
        }
    }
}
