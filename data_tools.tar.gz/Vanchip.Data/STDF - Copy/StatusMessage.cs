﻿namespace STDF_V4
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void StatusMessage(string message);
}

