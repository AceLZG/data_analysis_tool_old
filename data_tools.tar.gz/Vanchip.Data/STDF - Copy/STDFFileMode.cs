﻿namespace STDF_V4
{
    using System;

    public enum STDFFileMode
    {
        Read = 1,
        Write = 2
    }
}

