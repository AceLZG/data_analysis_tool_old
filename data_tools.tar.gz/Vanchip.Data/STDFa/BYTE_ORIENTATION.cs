﻿namespace STDFInterface
{
    using System;

    public enum BYTE_ORIENTATION
    {
        DEC = 0,
        IBMPC = 2,
        SUN = 1,
        UNKNOWN = -1
    }
}

