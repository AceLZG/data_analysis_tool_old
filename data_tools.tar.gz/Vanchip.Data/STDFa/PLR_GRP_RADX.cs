﻿namespace STDFInterface
{
    using System;

    public enum PLR_GRP_RADX
    {
        Binary = 2,
        Decimal = 10,
        Default = 0,
        Hex = 0x10,
        Octal = 8,
        Symbolic = 20
    }
}

