﻿namespace STDFInterface
{
    using System;

    public enum GDR_DataTypeCode
    {
        B0 = 0,
        BN = 11,
        CN = 10,
        DN = 12,
        I1 = 4,
        I2 = 5,
        I4 = 6,
        N1 = 13,
        R4 = 7,
        R8 = 8,
        U1 = 1,
        U2 = 2,
        U4 = 3
    }
}

