﻿namespace STDFInterface
{
    using System;

    public enum STDFFileMode
    {
        Read = 1,
        Write = 2
    }
}

