﻿namespace STDFInterface
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void StatusMessage(string message);
}

